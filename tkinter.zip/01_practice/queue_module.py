import queue
queue = queue.Queue()

queue.put(1)
queue.put(2)
queue.put(3)
queue.put(4)

queue.get()


print(queue.queue)